<?php
require 'pdo.php';
session_start();

$championship = null;
$teams = [];
$schedule = [];

if (isset($_GET['id'])) {
    $idCampionato = $_GET['id'];

    // Query the database for the championship
    $stmt = $pdo->prepare('SELECT * FROM ProgNat_Campionati WHERE id = ?');
    $stmt->execute([$idCampionato]);
    $championship = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($championship) {
        // Query the database for the teams in the championship
        $stmt = $pdo->prepare('SELECT * FROM ProgNat_Squadre WHERE championship_id = ?');
        $stmt->execute([$idCampionato]);
        $teams = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Create a mapping of team IDs to team names
        $teamNames = [];
        foreach ($teams as $team) {
            $teamNames[$team['id']] = $team['name'];
        }

        // Query the database for the schedule
        $stmt = $pdo->prepare('SELECT * FROM ProgNat_Calendario WHERE championship_id = ? ORDER BY match_date');
        $stmt->execute([$idCampionato]);
        $schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Championship not found, show alert
        echo "<script>alert('Campionato inesistente.'); window.location.href='home.php';</script>";
        exit();
    }
}
?>
<!doctype html>
<html lang="it">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Visualizza Campionato</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="img/icona.ico" type="image/x-icon">
  </head>
  <body>
    <div class="container">
      <h1 class="text-center mt-5">Dettagli Campionato</h1>
      <?php if ($championship): ?>
        <h2 class="mt-4">Nome Campionato: <?php echo htmlspecialchars($championship['name']); ?></h2>
        <h3 class="mt-4">Squadre:</h3>
        <ul class="list-group">
          <?php foreach ($teams as $team): ?>
            <li class="list-group-item"><?php echo htmlspecialchars($team['name']); ?></li>
          <?php endforeach; ?>
        </ul>
        <h3 class="mt-4">Calendario:</h3>
        <ul class="list-group">
          <?php foreach ($schedule as $match): ?>
            <li class="list-group-item">
              <?php
              $homeTeam = $teamNames[$match['home_team_id']];
              $awayTeam = $teamNames[$match['away_team_id']];
              echo htmlspecialchars($homeTeam) . ' vs ' . htmlspecialchars($awayTeam) . ' - ' . htmlspecialchars($match['match_date']);
              ?>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <div class="alert alert-danger mt-4" role="alert">
          Campionato non trovato.
        </div>
      <?php endif; ?>
      <a href="home.php" class="btn btn-primary mt-4">Torna alla Home</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>