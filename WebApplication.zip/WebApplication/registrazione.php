<!doctype html>
<html lang="it">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HoopManager Registrazione</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="img/icona.ico" type="image/x-icon">
  </head>
  <body>
    <div class="container-fluid">
      <nav class="navbar navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
          <div class="d-flex justify-content-between w-100">
            <a class="navbar-brand">
              <img src="img/logo-removebg-preview.png" alt="Logo" width="160" height="110" class="d-inline-block align-text-top">
            </a>
          </div>
        </div>
      </nav>
    </div>   
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
      <div style="width: 100%; max-width: 500px;" class="pt-5">
        <h2 class="text-center mb-4">Registrazione</h2>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            require 'pdo.php';
            $name = $_POST['name'];
            $surname = $_POST['surname'];
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

            $stmt = $pdo->prepare('INSERT INTO ProgNat_Amministratore (nome, cognome, username, mail, password) VALUES (?, ?, ?, ?, ?)');
            if ($stmt->execute([$name, $surname, $username, $email, $password])) {
                header('Location: home.php');
                exit();
            } else {
                echo '<div class="alert alert-danger" role="alert">Errore durante la registrazione. Riprova.</div>';
            }
        }
        ?>
        <form action="" method="post">
          <div class="mb-3">
            <label for="name" class="form-label">Nome</label>
            <input type="text" class="form-control" id="name" name="name" required>
          </div>  
          <div class="mb-3">
            <label for="surname" class="form-label">Cognome</label>
            <input type="text" class="form-control" id="surname" name="surname" required>
          </div>
          <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
          </div>
          <div class="mb-3">
            <label for="confirm_password" class="form-label">Conferma Password</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Registrati</button>
        </form>
        <p class="text-center mt-3">Già registrato? <a href="login.php">Accedi</a></p>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>