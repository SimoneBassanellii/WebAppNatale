<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}
$nome = $_SESSION['nome'];
$cognome = $_SESSION['cognome'];
?>
<!doctype html>
<html lang="it">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HoopManager Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="img/icona.ico" type="image/x-icon">
    <script>
      function toggleVisualizzaForm() {
        var visualizzaFormContainer = document.getElementById('visualizzaFormContainer');
        var aggiungiFormContainer = document.getElementById('aggiungiFormContainer');
        
        if (visualizzaFormContainer.style.display === 'none') {
            visualizzaFormContainer.style.display = 'block';
            aggiungiFormContainer.style.display = 'none';
        } else {
            visualizzaFormContainer.style.display = 'none';
        }
      }

      function toggleAggiungiForm() {
        var aggiungiFormContainer = document.getElementById('aggiungiFormContainer');
        var visualizzaFormContainer = document.getElementById('visualizzaFormContainer');
        
        if (aggiungiFormContainer.style.display === 'none') {
            aggiungiFormContainer.style.display = 'block';
            visualizzaFormContainer.style.display = 'none';
        } else {
            aggiungiFormContainer.style.display = 'none';
        }
      }

      function generateTeamInputs() {
        var numeroSquadre = document.getElementById('numero_squadre').value;
        var teamNamesContainer = document.getElementById('teamNamesContainer');
        teamNamesContainer.innerHTML = '';

        for (var i = 1; i <= numeroSquadre; i++) {
            var div = document.createElement('div');
            div.className = 'mb-3';
            var label = document.createElement('label');
            label.className = 'form-label';
            label.innerText = 'Nome Squadra ' + i;
            var input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control';
            input.name = 'team_names[]';
            input.required = true;
            div.appendChild(label);
            div.appendChild(input);
            teamNamesContainer.appendChild(div);
        }
      }

      function validateForm() {
        var teamNames = document.getElementsByName('team_names[]');
        for (var i = 0; i < teamNames.length; i++) {
            if (teamNames[i].value.trim() === '') {
                alert('Per favore, compila tutti i campi dei nomi delle squadre.');
                return false;
            }
        }
        return true;
      }
    </script>
  </head>
  <body>
    <?php if (isset($championshipId)): ?>
      <script>
        alert('Campionato creato con successo! ID Campionato: <?php echo $championshipId; ?>');
      </script>
    <?php endif; ?>
    <div class="container-fluid">
      <nav class="navbar navbar-dark bg-dark fixed-top">
        <div class="container-fluid d-flex justify-content-between align-items-center">
          <a class="navbar-brand">
            <img src="img/logo-removebg-preview.png" alt="Logo" width="160" height="110" class="d-inline-block align-text-top">
          </a>
          <div class="dropdown">
            <button class="btn btn-outline-light dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
              <?php echo htmlspecialchars($nome) . ' ' . htmlspecialchars($cognome); ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
              <li><a class="dropdown-item" href="logout.php">Logout</a></li>
            </ul>
          </div>
        </div>
      </nav>
    </div>  
    <div class="d-flex">
      <div class="bg-dark text-white p-3 sidebar" style="min-height: 100vh;">
        <h4 class="text-center">Menu</h4>
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link text-white" href="#" onclick="toggleVisualizzaForm()">Visualizza</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#" onclick="toggleAggiungiForm()">Aggiungi</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="visualizza_campionati.php">I Miei Campionati</a>
          </li>
        </ul>
      </div>
      <div class="container content">
        <div id="visualizzaFormContainer" class="mt-4" style="display: none;">
          <h2 class="text-center mb-4">Inserire ID Campionato</h2>
          <form action="visualizza_campionato.php" method="post">
            <div class="mb-3">
              <label for="id_campionato" class="form-label">ID Campionato</label>
              <input type="text" class="form-control" id="id_campionato" name="id_campionato" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Visualizza</button>
          </form>
        </div>
        <div id="aggiungiFormContainer" class="mt-4" style="display: none;">
          <h2 class="text-center mb-4">Aggiungi Campionato</h2>
          <form id="aggiungiForm" action="aggiungi_campionato.php" method="post" onsubmit="return validateForm()">
            <div class="mb-3">
              <label for="nome_campionato" class="form-label">Nome Campionato</label>
              <input type="text" class="form-control" id="nome_campionato" name="nome_campionato" required>
            </div>
            <div class="mb-3">
              <label for="numero_squadre" class="form-label">Numero di Squadre</label>
              <input type="number" class="form-control" id="numero_squadre" name="numero_squadre" required>
            </div>
            <div id="teamNamesContainer"></div>
            <button type="button" class="btn btn-secondary w-100" onclick="generateTeamInputs()">Inserisci le squadre</button>
            <button type="submit" class="btn btn-primary w-100 mt-3">Aggiungi</button>
          </form>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>