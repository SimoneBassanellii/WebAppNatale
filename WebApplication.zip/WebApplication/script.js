// Funzioni esistenti
function toggleVisualizzaForm() {
    var visualizzaFormContainer = document.getElementById('visualizzaFormContainer');
    var aggiungiFormContainer = document.getElementById('aggiungiFormContainer');
    
    if (visualizzaFormContainer.style.display === 'none') {
        visualizzaFormContainer.style.display = 'block';
        aggiungiFormContainer.style.display = 'none';
    } else {
        visualizzaFormContainer.style.display = 'none';
    }
}

function toggleAggiungiForm() {
    var aggiungiFormContainer = document.getElementById('aggiungiFormContainer');
    var visualizzaFormContainer = document.getElementById('visualizzaFormContainer');
    
    if (aggiungiFormContainer.style.display === 'none') {
        aggiungiFormContainer.style.display = 'block';
        visualizzaFormContainer.style.display = 'none';
    } else {
        aggiungiFormContainer.style.display = 'none';
    }
}

function generateTeamInputs() {
    var numeroSquadre = document.getElementById('numero_squadre').value;
    var teamNamesContainer = document.getElementById('teamNamesContainer');
    teamNamesContainer.innerHTML = '';

    for (var i = 1; i <= numeroSquadre; i++) {
        var div = document.createElement('div');
        div.className = 'mb-3';
        var label = document.createElement('label');
        label.className = 'form-label';
        label.innerText = 'Nome Squadra ' + i;
        var input = document.createElement('input');
        input.type = 'text';
        input.className = 'form-control';
        input.name = 'team_names[]';
        input.required = true;
        div.appendChild(label);
        div.appendChild(input);
        teamNamesContainer.appendChild(div);
    }
}

function validateForm() {
    var teamNames = document.getElementsByName('team_names[]');
    for (var i = 0; i < teamNames.length; i++) {
        if (teamNames[i].value.trim() === '') {
            alert('Per favore, compila tutti i campi dei nomi delle squadre.');
            return false;
        }
    }
    return true;
}
