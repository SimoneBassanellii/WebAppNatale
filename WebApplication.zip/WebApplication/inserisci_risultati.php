<?php
session_start();

require 'pdo.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $idCampionato = $_POST['id_campionato'];
    $idPartita = $_POST['id_partita'];
    $risultato = $_POST['risultato'];

    // Check if the user is the creator of the championship
    $stmt = $pdo->prepare('SELECT creator_id FROM ProgNat_Campionati WHERE id = ?');
    $stmt->execute([$idCampionato]);
    $championship = $stmt->fetch();

    if ($championship && $championship['creator_id'] == $_SESSION['user_id']) {
        // Insert the result
        $stmt = $pdo->prepare('UPDATE ProgNat_Calendario SET risultato = ? WHERE id = ? AND championship_id = ?');
        $stmt->execute([$risultato, $idPartita, $idCampionato]);

        echo "Risultato inserito con successo!";
    } else {
        echo "Non sei autorizzato a inserire i risultati per questo campionato.";
    }
}
?>
<!doctype html>
<html lang="it">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inserisci Risultati</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="img/icona.ico" type="image/x-icon">
  </head>
  <body>
    <div class="container">
      <h1 class="text-center mt-5">Inserisci Risultati</h1>
      <a href="home.php" class="btn btn-primary mt-4">Torna alla Home</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></script>
  </body>
</html>