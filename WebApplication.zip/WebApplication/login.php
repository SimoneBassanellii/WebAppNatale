<?php
require 'pdo.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query the database for the user
    $stmt = $pdo->prepare('SELECT * FROM ProgNat_Amministratore WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Set user details in session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nome'] = $user['nome'];
        $_SESSION['cognome'] = $user['cognome'];
        $_SESSION['loggedin'] = true;
        header('Location: home.php');
        exit();
    } else {
        echo '<div class="alert alert-danger" role="alert">Invalid username or password.</div>';
    }
}
?>
<!doctype html>
<html lang="it">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HoopManager Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="img/icona.ico" type="image/x-icon">
  </head>
  <body>
    <div class="container-fluid">
      <nav class="navbar navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
          <div class="d-flex justify-content-between w-100">
            <a class="navbar-brand">
              <img src="img/logo-removebg-preview.png" alt="Logo" width="160" height="110" class="d-inline-block align-text-top">
            </a>
          </div>
        </div>
      </nav>
    </div>   
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
      <div style="width: 100%; max-width: 500px;" class="pt-5">
        <h2 class="text-center mb-4">Login</h2>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];

            // Query the database for the user
            $stmt = $pdo->prepare('SELECT * FROM ProgNat_Amministratore WHERE username = ?');
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Set user details in session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['nome'] = $user['nome'];
                $_SESSION['cognome'] = $user['cognome'];
                $_SESSION['loggedin'] = true;
                header('Location: home.php');
                exit();
            } else {
                echo '<div class="alert alert-danger" role="alert">Invalid username or password.</div>';
            }
        }
        ?>
        <form action="" method="post">
          <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
        <div class="text-center mt-3">
          <p>Non hai un account? <a href="registrazione.php">Registrati</a></p>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>