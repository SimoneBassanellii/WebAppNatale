<?php
require 'pdo.php';
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

function generateSchedule($teamIds) {
    $schedule = [];
    $numTeams = count($teamIds);

    // If the number of teams is odd, add a dummy team
    $dummy = false;
    if ($numTeams % 2 != 0) {
        $teamIds[] = null; // null represents a bye week
        $numTeams++;
        $dummy = true;
    }

    $numRounds = $numTeams - 1;
    $matchesPerRound = $numTeams / 2;

    for ($round = 0; $round < $numRounds; $round++) {
        for ($match = 0; $match < $matchesPerRound; $match++) {
            $home = ($round + $match) % ($numTeams - 1);
            $away = ($numTeams - 1 - $match + $round) % ($numTeams - 1);

            if ($match == 0) {
                $away = $numTeams - 1;
            }

            if ($teamIds[$home] !== null && $teamIds[$away] !== null) {
                $schedule[] = [
                    'home_team_id' => $teamIds[$home],
                    'away_team_id' => $teamIds[$away],
                    'match_date' => date('Y-m-d', strtotime("+$round week"))
                ];

                // Reverse fixture
                $schedule[] = [
                    'home_team_id' => $teamIds[$away],
                    'away_team_id' => $teamIds[$home],
                    'match_date' => date('Y-m-d', strtotime("+" . ($round + $numRounds) . " week"))
                ];
            }
        }
    }

    // Remove matches involving the dummy team
    if ($dummy) {
        $schedule = array_filter($schedule, function($match) {
            return $match['home_team_id'] !== null && $match['away_team_id'] !== null;
        });
    }

    return $schedule;
}

function validateTeamNames($teamNames) {
    return count($teamNames) === count(array_unique($teamNames));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nomeCampionato = $_POST['nome_campionato'];
    $teamNames = $_POST['team_names'];

    // Ensure user_id is set in the session
    if (!isset($_SESSION['user_id'])) {
        echo "User ID not set in session.";
        exit();
    }

    $userId = $_SESSION['user_id'];

    // Validate team names
    if (!validateTeamNames($teamNames)) {
        echo "<script>alert('I nomi delle squadre devono essere unici.'); window.location.href='home.php';</script>";
        exit();
    }

    // Validate championship name
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM ProgNat_Campionati WHERE name = ?');
    $stmt->execute([$nomeCampionato]);
    $count = $stmt->fetchColumn(); 

    if ($count > 0) {
        echo "<script>alert('Il nome del campionato esiste già.'); window.history.back();</script>";
        exit();
    }

    try {
        // Begin a transaction
        $pdo->beginTransaction();

        // Insert championship
        $stmt = $pdo->prepare('INSERT INTO ProgNat_Campionati (name, creator_id) VALUES (?, ?)');
        $stmt->execute([$nomeCampionato, $userId]);
        $championshipId = $pdo->lastInsertId();

        // Insert teams
        $stmt = $pdo->prepare('INSERT INTO ProgNat_Squadre (championship_id, name) VALUES (?, ?)');
        $teamIds = [];
        foreach ($teamNames as $teamName) {
            $stmt->execute([$championshipId, $teamName]);
            $teamIds[] = $pdo->lastInsertId();
        }

        // If the number of teams is odd, add a "Riposo" team
        if (count($teamIds) % 2 != 0) {
            $stmt->execute([$championshipId, 'Riposo']);
            $teamIds[] = $pdo->lastInsertId();
        }

        // Generate and insert schedule
        $schedule = generateSchedule($teamIds);
        $stmt = $pdo->prepare('INSERT INTO ProgNat_Calendario (championship_id, home_team_id, away_team_id, match_date) VALUES (?, ?, ?, ?)');
        foreach ($schedule as $match) {
            $stmt->execute([$championshipId, $match['home_team_id'], $match['away_team_id'], $match['match_date']]);
        }

        // Commit the transaction
        $pdo->commit();

        // Show alert with championship ID
        echo "<script>alert('Campionato creato con successo! ID Campionato: $championshipId'); window.location.href='home.php';</script>";
        exit();
    } catch (Exception $e) {
        // Rollback the transaction if something failed
        $pdo->rollBack();
        echo "Failed: " . $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="it">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aggiungi Campionato</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="img/icona.ico" type="image/x-icon">
    <script>
      function validateForm() {
        const teamNames = document.getElementsByName('team_names[]');
        const nomeCampionato = document.getElementById('nome_campionato').value;
        const namesSet = new Set();

        for (let i = 0; i < teamNames.length; i++) {
          const name = teamNames[i].value.trim();
          if (namesSet.has(name)) {
            alert('I nomi delle squadre devono essere unici.');
            return false;
          }
          namesSet.add(name);
        }

        if (nomeCampionato === '') {
          alert('Il nome del campionato non può essere vuoto.');
          return false;
        }

        return true;
      }

      function generateTeamInputs() {
        const numTeams = document.getElementById('numero_squadre').value;
        const container = document.getElementById('teamNamesContainer');
        container.innerHTML = '';

        for (let i = 0; i < numTeams; i++) {
          const div = document.createElement('div');
          div.className = 'mb-3';
          const label = document.createElement('label');
          label.className = 'form-label';
          label.textContent = `Nome Squadra ${i + 1}`;
          const input = document.createElement('input');
          input.type = 'text';
          input.className = 'form-control';
          input.name = 'team_names[]';
          input.required = true;
          div.appendChild(label);
          div.appendChild(input);
          container.appendChild(div);
        }
      }
    </script>
  </head>
  <body>
    <div class="container">
      <h2 class="text-center mb-4">Aggiungi Campionato</h2>
      <form id="aggiungiForm" action="aggiungi_campionato.php" method="post" onsubmit="return validateForm()">
        <div class="mb-3">
          <label for="nome_campionato" class="form-label">Nome Campionato</label>
          <input type="text" class="form-control" id="nome_campionato" name="nome_campionato" required>
        </div>
        <div class="mb-3">
          <label for="numero_squadre" class="form-label">Numero di Squadre</label>
          <input type="number" class="form-control" id="numero_squadre" name="numero_squadre" required>
        </div>
        <div id="teamNamesContainer"></div>
        <button type="button" class="btn btn-secondary w-100" onclick="generateTeamInputs()">Inserisci le squadre</button>
        <button type="submit" class="btn btn-primary w-100 mt-3">Aggiungi</button>
      </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>