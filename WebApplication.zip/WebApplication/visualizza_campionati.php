<?php
require 'pdo.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Query the database for championships created by the logged-in user
$stmt = $pdo->prepare('SELECT * FROM ProgNat_Campionati WHERE creator_id = ?');
$stmt->execute([$userId]);
$championships = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="it">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>I Miei Campionati</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="img/icona.ico" type="image/x-icon">
  </head>
  <body>
    <div class="container">
      <h1 class="text-center mt-5">I Miei Campionati</h1>
      <?php if (count($championships) > 0): ?>
        <ul class="list-group mt-4">
          <?php foreach ($championships as $championship): ?>
            <li class="list-group-item">
              <a href="visualizza_campionato.php?id=<?php echo $championship['id']; ?>">
                <?php echo htmlspecialchars($championship['name']); ?>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <div class="alert alert-info mt-4" role="alert">
          Non hai creato nessun campionato.
        </div>
      <?php endif; ?>
      <a href="home.php" class="btn btn-primary mt-4">Torna alla Home</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>