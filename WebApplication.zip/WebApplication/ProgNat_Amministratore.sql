-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Gen 12, 2025 alle 22:40
-- Versione del server: 8.0.26
-- Versione PHP: 8.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_sdkfz181`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `ProgNat_Amministratore`
--

CREATE TABLE `ProgNat_Amministratore` (
  `id` int NOT NULL,
  `nome` varchar(30) NOT NULL,
  `cognome` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `username` varchar(50) NOT NULL,
  `mail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `ProgNat_Amministratore`
--

INSERT INTO `ProgNat_Amministratore` (`id`, `nome`, `cognome`, `username`, `mail`, `password`) VALUES
(4, 'mario', 'rossi', 'wasd', 'simone.bassanelli06@gmail.com', '$2y$10$ebpuytUeWoxSLYPdRMLWXe3Pkr00Ptjo2pkuX3gIf46Ja2IjzqERa'),
(3, 'simone', 'bassanelli', 'wasd', 'simone.bassanelli06@gmail.com', '$2y$10$lmjkVXBoZz7cihQ0UEyW..D6GgQIBNlvK7NmbxipdJ.LMTHw2pNnS'),
(5, 'luigi', 'verdi', 'luigione', 'qwerty@gmail.com', '$2y$10$yHcOOzmZMimSCyb438ZJLuMQR2fhVoBaWI36WW6oRWPnxo7434LT6');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `ProgNat_Amministratore`
--
ALTER TABLE `ProgNat_Amministratore`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `ProgNat_Amministratore`
--
ALTER TABLE `ProgNat_Amministratore`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
